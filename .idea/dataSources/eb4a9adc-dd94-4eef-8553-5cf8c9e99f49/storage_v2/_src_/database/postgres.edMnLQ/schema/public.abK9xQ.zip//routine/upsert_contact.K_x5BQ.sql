create procedure upsert_contact(IN p_name text, IN p_phone text)
    language plpgsql
as
$$
BEGIN
    INSERT INTO contacts(name, phone)
    VALUES(p_name, p_phone)
    ON CONFLICT(phone) DO UPDATE
    SET name = EXCLUDED.name;
END;
$$;

alter procedure upsert_contact(text, text) owner to postgres;

