create function get_contacts_by_pattern(p_pattern text)
    returns TABLE(id integer, name character varying, phone character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT * FROM contacts
    WHERE name ILIKE '%' || p_pattern || '%'
       OR phone ILIKE '%' || p_pattern || '%';
END;
$$;

alter function get_contacts_by_pattern(text) owner to postgres;

