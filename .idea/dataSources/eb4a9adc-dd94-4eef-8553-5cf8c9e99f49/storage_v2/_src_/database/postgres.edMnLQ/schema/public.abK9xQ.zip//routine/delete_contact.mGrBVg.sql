create procedure delete_contact(IN p_value text)
    language plpgsql
as
$$
BEGIN
    DELETE FROM contacts WHERE name = p_value OR phone = p_value;
END;
$$;

alter procedure delete_contact(text) owner to postgres;

