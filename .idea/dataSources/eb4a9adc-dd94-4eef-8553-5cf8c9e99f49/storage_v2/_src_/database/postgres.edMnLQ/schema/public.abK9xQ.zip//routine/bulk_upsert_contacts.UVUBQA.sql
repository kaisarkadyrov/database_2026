create procedure bulk_upsert_contacts(IN p_names text[], IN p_phones text[])
    language plpgsql
as
$$
DECLARE
    i integer;
BEGIN
    FOR i IN array_lower(p_names,1)..array_upper(p_names,1) LOOP
        CALL upsert_contact(p_names[i], p_phones[i]);
    END LOOP;
END;
$$;

alter procedure bulk_upsert_contacts(text[], text[]) owner to postgres;

