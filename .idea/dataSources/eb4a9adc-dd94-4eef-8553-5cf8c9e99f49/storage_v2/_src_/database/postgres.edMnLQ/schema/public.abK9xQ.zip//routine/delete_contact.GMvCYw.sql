create procedure delete_contact(IN p_value character varying)
    language plpgsql
as
$$
BEGIN
    DELETE FROM contacts WHERE name = p_value OR phone = p_value;
END;
$$;

alter procedure delete_contact(varchar) owner to postgres;

