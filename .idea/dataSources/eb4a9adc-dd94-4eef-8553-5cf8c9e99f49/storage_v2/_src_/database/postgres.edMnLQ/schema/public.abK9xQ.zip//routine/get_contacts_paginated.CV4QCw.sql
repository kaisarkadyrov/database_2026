create function get_contacts_paginated(p_limit integer, p_offset integer)
    returns TABLE(id integer, name character varying, phone character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT * FROM contacts
    ORDER BY id
    LIMIT p_limit OFFSET p_offset;
END;
$$;

alter function get_contacts_paginated(integer, integer) owner to postgres;

