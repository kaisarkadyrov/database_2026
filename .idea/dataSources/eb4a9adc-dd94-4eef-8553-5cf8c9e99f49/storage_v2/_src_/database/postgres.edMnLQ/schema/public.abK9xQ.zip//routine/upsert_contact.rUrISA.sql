create procedure upsert_contact(IN p_name character varying, IN p_phone character varying)
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT 1 FROM contacts WHERE name = p_name) THEN
        UPDATE contacts SET phone = p_phone WHERE name = p_name;
    ELSE
        INSERT INTO contacts(name, phone) VALUES(p_name, p_phone);
    END IF;
END;
$$;

alter procedure upsert_contact(varchar, varchar) owner to postgres;

